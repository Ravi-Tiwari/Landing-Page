import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";



@Component({
  selector: 'app-ongoin-tickets',
  templateUrl: './ongoin-tickets.component.html',
  styleUrls: ['./ongoin-tickets.component.css']
})
export class OngoinTicketsComponent  {

  displayedColumns = ['loren', 'loren1', 'loren2','loren3','loren4','loren5','loren6',];
  transactions: any = [];


  constructor(private httpClient: HttpClient){}
  ngOnInit(){
    this.httpClient.get("./assets/user.json").subscribe(data =>{
      this.transactions = data;
    })
  }
  
}


