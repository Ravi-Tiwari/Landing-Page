import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OngoinBatchesComponent } from './ongoin-batches.component';

describe('OngoinBatchesComponent', () => {
  let component: OngoinBatchesComponent;
  let fixture: ComponentFixture<OngoinBatchesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OngoinBatchesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OngoinBatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
