import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chartlist',
  templateUrl: './chartlist.component.html',
  styleUrls: ['./chartlist.component.css']
})
export class ChartlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
