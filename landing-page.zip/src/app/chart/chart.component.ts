import { Component, OnInit, ViewChild } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from "chart.js";
import { Label } from "ng2-charts";

import * as Chart from 'chart.js'
@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit {
  public barChartData2: any[]=[
    // {data: [10], label: 'Series A'},
    // {data: [10], label: 'Series B'}

   {data: [6500, 590, 800, 810, 560, 550, 400], label: 'Series A'},
   {data: [2800, 480, 400, 190, 860, 207, 900], label: 'Series B'}
 
 ];
 public barChartLabels:string[] = [ 'Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
 public barChartType:any = 'doughnut';
 public barChartLegend:boolean = false;
 public barChartData:any[] = [
   {data: [6500, 590, 800, 810, 560, 550, 400], label: 'Series A'},
   {data: [2800, 480, 400, 190, 860, 207, 900], label: 'Series B'}
 ];
  ngOnInit(): void {
  }

}
