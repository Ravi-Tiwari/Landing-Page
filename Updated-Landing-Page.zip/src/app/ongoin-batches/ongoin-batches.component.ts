import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ongoin-batches',
  templateUrl: './ongoin-batches.component.html',
  styleUrls: ['./ongoin-batches.component.css']
})
export class OngoinBatchesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
