import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OngoinTicketsComponent } from './ongoin-tickets.component';

describe('OngoinTicketsComponent', () => {
  let component: OngoinTicketsComponent;
  let fixture: ComponentFixture<OngoinTicketsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OngoinTicketsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OngoinTicketsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
